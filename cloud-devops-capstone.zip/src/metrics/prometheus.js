/**
 * CloudPulse - Prometheus Telemetry & Metrics Exporter
 * Implements RED Method: Rate, Errors, Duration
 */

const client = require('prom-client');
const config = require('../config');

// Dedicated Registry
const register = new client.Registry();

// Default Node.js Runtime & OS Metrics
client.collectDefaultMetrics({
  register,
  prefix: 'nodejs_',
  labels: { app: config.appName, env: config.nodeEnv }
});

// 1. RATE: Total HTTP Requests Processed
const httpRequestsTotal = new client.Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests processed by endpoint and status',
  labelNames: ['method', 'route', 'status_code'],
  registers: [register]
});

// 2. DURATION: Request Latency Histogram
const httpRequestDurationSeconds = new client.Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5],
  registers: [register]
});

// 3. ERRORS: 4xx and 5xx Error Counts
const httpErrorsTotal = new client.Counter({
  name: 'http_errors_total',
  help: 'Total number of HTTP errors generated',
  labelNames: ['method', 'route', 'status_code', 'error_type'],
  registers: [register]
});

// In-Flight Active Requests
const activeRequestsGauge = new client.Gauge({
  name: 'http_active_requests',
  help: 'Number of currently in-flight HTTP requests',
  registers: [register]
});

// Database Connection Pool Status
const dbConnectionsGauge = new client.Gauge({
  name: 'db_active_connections',
  help: 'Active connections to PostgreSQL database pool',
  labelNames: ['state'],
  registers: [register]
});

// Active Cloud Incidents
const activeIncidentsGauge = new client.Gauge({
  name: 'cloud_incidents_active_count',
  help: 'Number of currently active/open cloud incidents',
  labelNames: ['severity'],
  registers: [register]
});

// Application Info Metric
const appInfoGauge = new client.Gauge({
  name: 'cloudpulse_app_info',
  help: 'Metadata including application version, environment, and build ID',
  labelNames: ['version', 'environment', 'build_id'],
  registers: [register]
});

appInfoGauge.labels(config.appVersion, config.nodeEnv, config.buildId).set(1);

// Sliding window counters for frontend dashboard polling
const metricsHistory = {
  requestRatePerMin: 0,
  errorCountLastMin: 0,
  latencySamples: [],
  historyTimeline: []
};

// Periodic window calculator (every 5 seconds)
setInterval(() => {
  const avgLatency = metricsHistory.latencySamples.length > 0
    ? (metricsHistory.latencySamples.reduce((a, b) => a + b, 0) / metricsHistory.latencySamples.length).toFixed(2)
    : 0;

  metricsHistory.historyTimeline.push({
    timestamp: new Date().toLocaleTimeString(),
    requests: metricsHistory.requestRatePerMin,
    errors: metricsHistory.errorCountLastMin,
    avgLatency: parseFloat(avgLatency)
  });

  if (metricsHistory.historyTimeline.length > 20) {
    metricsHistory.historyTimeline.shift();
  }

  // Reset rolling counters
  metricsHistory.requestRatePerMin = 0;
  metricsHistory.errorCountLastMin = 0;
  metricsHistory.latencySamples = [];
}, 5000);

module.exports = {
  register,
  client,
  metrics: {
    httpRequestsTotal,
    httpRequestDurationSeconds,
    httpErrorsTotal,
    activeRequestsGauge,
    dbConnectionsGauge,
    activeIncidentsGauge,
    appInfoGauge
  },
  recordRequest(method, route, statusCode, durationSeconds) {
    const statusStr = statusCode.toString();
    httpRequestsTotal.inc({ method, route, status_code: statusStr });
    httpRequestDurationSeconds.observe({ method, route, status_code: statusStr }, durationSeconds);

    metricsHistory.requestRatePerMin += 1;
    metricsHistory.latencySamples.push(durationSeconds * 1000);

    if (statusCode >= 400) {
      const errorType = statusCode >= 500 ? 'server_error' : 'client_error';
      httpErrorsTotal.inc({ method, route, status_code: statusStr, error_type: errorType });
      metricsHistory.errorCountLastMin += 1;
    }
  },
  getMetricsSummary() {
    return {
      history: metricsHistory.historyTimeline,
      system: {
        memoryUsageMb: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2),
        uptimeSeconds: Math.floor(process.uptime()),
        nodeVersion: process.version
      }
    };
  }
};
