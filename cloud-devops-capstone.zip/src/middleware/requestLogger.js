/**
 * CloudPulse - Structured JSON Request Logger & Tracing Middleware
 */

const crypto = require('crypto');
const { recordRequest, metrics } = require('../metrics/prometheus');

function requestLogger(req, res, next) {
  // Extract or generate unique distributed request ID
  const correlationId = req.headers['x-request-id'] || `req-${crypto.randomBytes(6).toString('hex')}`;
  req.id = correlationId;
  res.setHeader('X-Request-ID', correlationId);

  const startTime = process.hrtime();
  metrics.activeRequestsGauge.inc();

  // Normalize route for Prometheus metric labels
  const getNormalizedRoute = () => {
    if (req.baseUrl || req.route) {
      return `${req.baseUrl || ''}${req.route ? req.route.path : ''}` || req.path;
    }
    return req.path || '/';
  };

  res.on('finish', () => {
    metrics.activeRequestsGauge.dec();
    const diff = process.hrtime(startTime);
    const durationSeconds = diff[0] + diff[1] / 1e9;
    const durationMs = (durationSeconds * 1000).toFixed(2);
    const route = getNormalizedRoute();

    // Record in Prometheus telemetry
    recordRequest(req.method, route, res.statusCode, durationSeconds);

    // Filter out asset spam in stdout logs if desired
    if (!req.path.startsWith('/public') && !req.path.endsWith('.ico')) {
      const logEntry = {
        level: res.statusCode >= 500 ? 'ERROR' : res.statusCode >= 400 ? 'WARN' : 'INFO',
        timestamp: new Date().toISOString(),
        requestId: correlationId,
        method: req.method,
        path: req.path,
        route,
        statusCode: res.statusCode,
        durationMs: parseFloat(durationMs),
        userAgent: req.get('user-agent') || 'internal-probe',
        clientIp: req.ip || req.connection.remoteAddress
      };

      if (logEntry.level === 'ERROR') {
        console.error(JSON.stringify(logEntry));
      } else {
        console.log(JSON.stringify(logEntry));
      }
    }
  });

  next();
}

module.exports = requestLogger;
