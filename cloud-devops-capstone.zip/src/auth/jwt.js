/**
 * CloudPulse - JWT Authentication & RBAC Middleware
 */

const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const config = require('../config');

function signToken(payload) {
  return jwt.sign(payload, config.jwt.secret, {
    expiresIn: config.jwt.expiresIn
  });
}

function verifyToken(token) {
  try {
    return jwt.verify(token, config.jwt.secret);
  } catch (err) {
    return null;
  }
}

function hashPassword(plainText) {
  return bcrypt.hashSync(plainText, 10);
}

function comparePassword(plainText, hash) {
  return bcrypt.compareSync(plainText, hash);
}

// Authentication Middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // Bearer <token>

  if (!token) {
    return res.status(401).json({
      error: 'Unauthorized',
      message: 'Access token required in Authorization header (Bearer <token>)'
    });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(403).json({
      error: 'Forbidden',
      message: 'Token is invalid or has expired'
    });
  }

  req.user = decoded;
  next();
}

// Role-Based Access Control Middleware
function requireRole(requiredRole) {
  return (req, res, next) => {
    if (!req.user || req.user.role !== requiredRole) {
      return res.status(403).json({
        error: 'Forbidden',
        message: `Insufficient permissions. Requires '${requiredRole}' role.`
      });
    }
    next();
  };
}

module.exports = {
  signToken,
  verifyToken,
  hashPassword,
  comparePassword,
  authenticateToken,
  requireRole
};
