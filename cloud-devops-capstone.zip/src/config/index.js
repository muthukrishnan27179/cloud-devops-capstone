/**
 * CloudPulse - Application Configuration
 */

require('dotenv').config();

module.exports = {
  port: parseInt(process.env.PORT, 10) || 3000,
  nodeEnv: process.env.NODE_ENV || 'development',
  appName: process.env.APP_NAME || 'cloudpulse-devops-platform',
  appVersion: process.env.APP_VERSION || '1.0.0',
  buildId: process.env.BUILD_ID || 'build-capstone-v1',
  
  // Security & JWT
  jwt: {
    secret: process.env.JWT_SECRET || 'devops_capstone_jwt_super_secret_key_2026_xyz987',
    expiresIn: process.env.JWT_EXPIRY || '24h'
  },

  // Managed Database
  db: {
    connectionString: process.env.DATABASE_URL || '',
    poolMin: parseInt(process.env.DB_POOL_MIN, 10) || 2,
    poolMax: parseInt(process.env.DB_POOL_MAX, 10) || 10,
    ssl: process.env.NODE_ENV === 'production' && !process.env.DATABASE_URL?.includes('localhost') 
      ? { rejectUnauthorized: false } 
      : false
  },

  // Telemetry & Metrics
  metrics: {
    enabled: process.env.METRICS_ENABLED !== 'false',
    prefix: 'cloudpulse_'
  },

  corsOrigin: process.env.CORS_ORIGIN || '*'
};
